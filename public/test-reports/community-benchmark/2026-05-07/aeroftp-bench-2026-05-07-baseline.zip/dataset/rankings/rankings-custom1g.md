# AeroFTP custom1g sweep — rankings

Reports analyzed: **27 OK / 0 no-data / 0 empty**

OK profiles: AWS, Alibaba_OSS, AzureBlob, Cloudfare_R2, Drime, FileLu, Filen_Dev, Google, Internxt, Jotta, Koofr, Mega_S3, MyBox, MyZoho, My_Dropbox, My_Google_Drive, My_Koofr_WebDAV, My_Mega, S3Drive, S3_Storj, S5_FileLu, Tencent, WebDav_DriveHQ, Yandex, aeroftp.app, jianguoyun, pCloud

## Payload 1 MB

### upload

| # | Profile | p50 Mbps | p95 Mbps |
|---|---------|----------|----------|
| 1 | Alibaba_OSS | 107.7 | 107.7 |
| 2 | AzureBlob | 91.3 | 94.5 |
| 3 | AWS | 65.1 | 68.2 |
| 4 | Tencent | 64.1 | 69.3 |
| 5 | S3Drive | 42.1 | 53.1 |
| 6 | S3_Storj | 39.5 | 41.7 |
| 7 | Google | 32.4 | 32.7 |
| 8 | Cloudfare_R2 | 29.4 | 34.5 |
| 9 | MyZoho | 24.3 | 26.3 |
| 10 | Jotta | 20.8 | 24.6 |
| 11 | WebDav_DriveHQ | 18.5 | 19.8 |
| 12 | Koofr | 18.3 | 24.4 |
| 13 | pCloud | 17.0 | 17.1 |
| 14 | Mega_S3 | 15.7 | 41.1 |
| 15 | aeroftp.app | 13.4 | 13.6 |
| 16 | My_Mega | 12.9 | 16.1 |
| 17 | My_Koofr_WebDAV | 12.6 | 12.9 |
| 18 | My_Dropbox | 12.5 | 12.7 |
| 19 | Filen_Dev | 6.2 | 7.0 |
| 20 | Internxt | 4.3 | 5.2 |
| 21 | My_Google_Drive | 3.8 | 3.9 |
| 22 | MyBox | 3.2 | 3.8 |
| 23 | jianguoyun | 2.1 | 2.1 |
| 24 | Drime | 2.0 | 2.0 |
| 25 | FileLu | 1.4 | 1.4 |
| 26 | S5_FileLu | 1.4 | 1.4 |
| 27 | Yandex | 0.8 | 0.9 |

### download

| # | Profile | p50 Mbps | p95 Mbps |
|---|---------|----------|----------|
| 1 | Mega_S3 | 83.7 | 84.9 |
| 2 | Tencent | 72.3 | 74.1 |
| 3 | Google | 62.3 | 67.0 |
| 4 | Alibaba_OSS | 60.5 | 83.7 |
| 5 | S3_Storj | 50.0 | 51.6 |
| 6 | Cloudfare_R2 | 46.6 | 48.2 |
| 7 | S3Drive | 43.9 | 46.7 |
| 8 | AzureBlob | 35.4 | 38.3 |
| 9 | Koofr | 32.7 | 37.2 |
| 10 | AWS | 31.1 | 37.9 |
| 11 | Jotta | 29.9 | 37.2 |
| 12 | Filen_Dev | 25.7 | 27.5 |
| 13 | jianguoyun | 21.4 | 21.4 |
| 14 | My_Koofr_WebDAV | 20.4 | 27.1 |
| 15 | aeroftp.app | 18.5 | 19.2 |
| 16 | pCloud | 16.6 | 16.7 |
| 17 | MyZoho | 11.4 | 12.5 |
| 18 | WebDav_DriveHQ | 10.7 | 10.9 |
| 19 | My_Dropbox | 9.6 | 10.1 |
| 20 | My_Mega | 9.6 | 11.7 |
| 21 | Internxt | 9.2 | 9.2 |
| 22 | My_Google_Drive | 6.8 | 8.2 |
| 23 | Yandex | 6.1 | 6.7 |
| 24 | FileLu | 5.4 | 5.6 |
| 25 | MyBox | 5.3 | 5.4 |
| 26 | Drime | 3.2 | 3.2 |
| 27 | S5_FileLu | 1.8 | 1.8 |

### list latency

### stat latency

### delete latency

## Payload 10 MB

### upload

| # | Profile | p50 Mbps | p95 Mbps |
|---|---------|----------|----------|
| 1 | Alibaba_OSS | 173.5 | 179.1 |
| 2 | AzureBlob | 161.7 | 161.9 |
| 3 | S3_Storj | 121.1 | 122.6 |
| 4 | Tencent | 108.3 | 119.4 |
| 5 | pCloud | 94.3 | 101.2 |
| 6 | Cloudfare_R2 | 89.1 | 91.0 |
| 7 | AWS | 76.9 | 80.2 |
| 8 | My_Dropbox | 69.3 | 87.6 |
| 9 | MyZoho | 67.7 | 68.3 |
| 10 | Google | 67.4 | 68.9 |
| 11 | S3Drive | 63.1 | 73.6 |
| 12 | Koofr | 51.5 | 56.8 |
| 13 | Jotta | 50.4 | 96.0 |
| 14 | My_Koofr_WebDAV | 45.9 | 57.9 |
| 15 | My_Mega | 40.6 | 56.4 |
| 16 | Mega_S3 | 39.4 | 44.9 |
| 17 | aeroftp.app | 30.7 | 31.7 |
| 18 | My_Google_Drive | 26.8 | 29.1 |
| 19 | WebDav_DriveHQ | 23.8 | 25.0 |
| 20 | Internxt | 21.6 | 23.3 |
| 21 | FileLu | 13.7 | 13.8 |
| 22 | MyBox | 13.1 | 13.4 |
| 23 | S5_FileLu | 6.7 | 6.8 |
| 24 | jianguoyun | 2.1 | 2.1 |
| 25 | Yandex | 1.0 | 1.0 |

### download

| # | Profile | p50 Mbps | p95 Mbps |
|---|---------|----------|----------|
| 1 | Google | 284.5 | 297.2 |
| 2 | Alibaba_OSS | 272.2 | 363.3 |
| 3 | Tencent | 223.5 | 298.2 |
| 4 | Cloudfare_R2 | 185.4 | 208.8 |
| 5 | S3_Storj | 155.8 | 158.5 |
| 6 | Jotta | 121.9 | 134.9 |
| 7 | My_Mega | 109.3 | 109.5 |
| 8 | aeroftp.app | 89.0 | 99.3 |
| 9 | Koofr | 87.1 | 98.3 |
| 10 | My_Koofr_WebDAV | 77.9 | 84.0 |
| 11 | Mega_S3 | 67.9 | 260.8 |
| 12 | My_Dropbox | 64.2 | 79.9 |
| 13 | MyZoho | 50.7 | 53.1 |
| 14 | My_Google_Drive | 50.0 | 52.9 |
| 15 | FileLu | 48.3 | 50.1 |
| 16 | MyBox | 45.9 | 48.5 |
| 17 | pCloud | 43.9 | 44.9 |
| 18 | jianguoyun | 43.7 | 43.9 |
| 19 | AzureBlob | 42.0 | 43.3 |
| 20 | S3Drive | 38.3 | 44.6 |
| 21 | Internxt | 35.8 | 42.4 |
| 22 | AWS | 34.1 | 36.3 |
| 23 | Yandex | 27.5 | 34.5 |
| 24 | WebDav_DriveHQ | 14.2 | 14.3 |
| 25 | S5_FileLu | 13.3 | 15.2 |

### list latency

### stat latency

### delete latency

## Payload 100 MB

### upload

| # | Profile | p50 Mbps | p95 Mbps |
|---|---------|----------|----------|
| 1 | AzureBlob | 281.3 | 281.6 |
| 2 | pCloud | 236.5 | 254.8 |
| 3 | Alibaba_OSS | 229.6 | 239.2 |
| 4 | My_Dropbox | 223.2 | 223.9 |
| 5 | S3_Storj | 194.3 | 195.5 |
| 6 | Tencent | 181.3 | 181.6 |
| 7 | Jotta | 168.1 | 212.2 |
| 8 | Cloudfare_R2 | 163.7 | 164.9 |
| 9 | Mega_S3 | 163.6 | 166.9 |
| 10 | Internxt | 149.8 | 167.1 |
| 11 | Google | 141.4 | 166.8 |
| 12 | S3Drive | 131.1 | 138.6 |
| 13 | aeroftp.app | 129.2 | 142.4 |
| 14 | AWS | 102.9 | 109.0 |
| 15 | Koofr | 101.5 | 110.5 |
| 16 | MyZoho | 99.1 | 102.2 |
| 17 | My_Google_Drive | 96.7 | 99.5 |
| 18 | FileLu | 92.5 | 96.9 |
| 19 | My_Mega | 72.5 | 77.9 |
| 20 | My_Koofr_WebDAV | 48.7 | 49.8 |
| 21 | MyBox | 37.9 | 39.6 |
| 22 | S5_FileLu | 29.3 | 29.3 |
| 23 | WebDav_DriveHQ | 23.4 | 25.8 |
| 24 | jianguoyun | 2.1 | 2.1 |

### download

| # | Profile | p50 Mbps | p95 Mbps |
|---|---------|----------|----------|
| 1 | Google | 615.3 | 631.5 |
| 2 | Alibaba_OSS | 594.0 | 609.6 |
| 3 | Mega_S3 | 546.7 | 551.2 |
| 4 | Tencent | 516.4 | 525.0 |
| 5 | Cloudfare_R2 | 401.3 | 406.8 |
| 6 | Jotta | 383.8 | 417.4 |
| 7 | My_Mega | 377.3 | 388.7 |
| 8 | FileLu | 229.2 | 229.4 |
| 9 | My_Dropbox | 183.7 | 199.7 |
| 10 | S3_Storj | 178.2 | 186.0 |
| 11 | Koofr | 156.2 | 161.5 |
| 12 | My_Koofr_WebDAV | 144.0 | 156.3 |
| 13 | My_Google_Drive | 136.6 | 161.4 |
| 14 | MyBox | 119.0 | 121.5 |
| 15 | aeroftp.app | 82.3 | 84.7 |
| 16 | MyZoho | 66.4 | 82.8 |
| 17 | Internxt | 64.9 | 66.2 |
| 18 | AWS | 62.6 | 71.4 |
| 19 | S5_FileLu | 57.5 | 58.0 |
| 20 | pCloud | 52.3 | 56.3 |
| 21 | jianguoyun | 44.0 | 44.4 |
| 22 | AzureBlob | 41.4 | 42.7 |
| 23 | S3Drive | 29.4 | 54.5 |
| 24 | WebDav_DriveHQ | 14.8 | 14.8 |

### list latency

### stat latency

### delete latency

## Payload 1 GB

### upload

| # | Profile | p50 Mbps | p95 Mbps |
|---|---------|----------|----------|
| 1 | pCloud | 281.8 | 285.3 |
| 2 | Jotta | 271.2 | 276.6 |
| 3 | My_Dropbox | 240.5 | 241.3 |
| 4 | Alibaba_OSS | 209.3 | 238.5 |
| 5 | aeroftp.app | 201.0 | 212.3 |
| 6 | S3_Storj | 188.1 | 189.9 |
| 7 | Cloudfare_R2 | 185.0 | 190.1 |
| 8 | FileLu | 183.8 | 187.9 |
| 9 | Tencent | 178.0 | 198.3 |
| 10 | Google | 167.8 | 184.2 |
| 11 | S3Drive | 165.6 | 168.5 |
| 12 | AzureBlob | 156.9 | 157.1 |
| 13 | Mega_S3 | 152.7 | 164.7 |
| 14 | AWS | 144.2 | 155.8 |
| 15 | My_Google_Drive | 129.4 | 138.9 |
| 16 | My_Koofr_WebDAV | 113.6 | 142.8 |
| 17 | My_Mega | 79.2 | 86.8 |
| 18 | S5_FileLu | 40.2 | 40.4 |

### download

| # | Profile | p50 Mbps | p95 Mbps |
|---|---------|----------|----------|
| 1 | Google | 585.1 | 616.3 |
| 2 | Mega_S3 | 584.9 | 588.4 |
| 3 | Tencent | 569.3 | 596.0 |
| 4 | Alibaba_OSS | 556.5 | 561.2 |
| 5 | Jotta | 471.1 | 475.2 |
| 6 | FileLu | 412.8 | 423.5 |
| 7 | My_Google_Drive | 304.5 | 336.2 |
| 8 | Cloudfare_R2 | 286.6 | 291.4 |
| 9 | My_Mega | 229.8 | 235.4 |
| 10 | My_Koofr_WebDAV | 210.0 | 213.9 |
| 11 | S3_Storj | 187.9 | 188.6 |
| 12 | My_Dropbox | 139.8 | 176.0 |
| 13 | S5_FileLu | 97.2 | 114.0 |
| 14 | aeroftp.app | 88.8 | 95.0 |
| 15 | S3Drive | 86.4 | 91.0 |
| 16 | pCloud | 80.1 | 84.8 |
| 17 | AWS | 76.8 | 86.8 |
| 18 | AzureBlob | 43.1 | 43.1 |

### list latency

### stat latency

### delete latency

## Errors digest

### Drime

- stat failed: Path not found: Folder 'aeroftp-bench' not found in /aeroftp-bench/b61d7cfa-24f7-40c1-b0d0-caa6c876ec85/aeroftp-bench
- delete failed: Path not found: Folder 'aeroftp-bench' not found in /aeroftp-bench/b61d7cfa-24f7-40c1-b0d0-caa6c876ec85/aeroftp-bench
- upload 10.0 MB bytes failed: Path not found: Folder 'aeroftp-bench' not found in /aeroftp-bench/b61d7cfa-24f7-40c1-b0d0-caa6c876ec85/aeroftp-bench
- cleanup of aeroftp-bench/b61d7cfa-24f7-40c1-b0d0-caa6c876ec85 returned error (manual review may be needed): Path not found: Folder 'aeroftp-bench' not found in /aeroftp-bench/b61d7cfa-24f7-40c1-b0d0-caa6c876ec85/aeroftp-bench

### Filen_Dev

- upload 10.0 MB bytes failed: Transfer failed: Upload chunk failed: 413 Payload Too Large - {"message":"Invalid request."}

### Internxt

- download 1048576 bytes failed: Path not found: File not found: /aeroftp-bench/a3cc533c-3322-4861-b782-ac06a7006f68/payload-1048576.bin
- upload 1.0 GB bytes failed: Server error: Start upload failed (420 <unknown status code>): {"error":"Max space used"}

### Koofr

- upload 1.0 GB bytes failed: Transfer failed: Upload failed: error sending request for url (https://app.koofr.net/content/api/v2.1/mounts/722a2d26-c47e-48a3-b515-187443725b64/files/put?path=%2Faeroftp-bench%2F51b23b53-2352-46a3-b60c-74df7ef0926b&filename=payload-1073741824.bin&autorename=true&overwrite=true&info=true&modified=1778167603772)

### MyBox

- upload 1.0 GB bytes failed: Transfer failed: Upload session failed: {"type":"error","status":403,"code":"file_size_limit_exceeded","help_url":"http:\/\/developers.box.com\/docs\/#errors","message":"File size exceeds the folder owner's file size limit","request_id":"1y3...

### MyZoho

- upload 1.0 GB bytes failed: Upload failed (413 Payload Too Large): <html>

### S5_FileLu

- delete failed: Server error: Delete failed with status: 500 Internal Server Error
- download 10485760 bytes failed: Path not found: aeroftp-bench/c5f75eaf-e706-4995-8a8a-40d3c375b12f/payload-10485760.bin
- delete failed: Server error: Delete failed with status: 500 Internal Server Error
- download 104857600 bytes failed: Path not found: aeroftp-bench/c5f75eaf-e706-4995-8a8a-40d3c375b12f/payload-104857600.bin
- delete failed: Server error: Delete failed with status: 500 Internal Server Error
- download 1073741824 bytes failed: Path not found: aeroftp-bench/c5f75eaf-e706-4995-8a8a-40d3c375b12f/payload-1073741824.bin
- ...and 2 more

### WebDav_DriveHQ

- upload 1.0 GB bytes failed: Transfer failed: Upload failed with status: 403 Forbidden

### Yandex

- upload 100.0 MB bytes failed: Transfer failed: error sending request for url (https://uploader746klg.disk.yandex.net/upload-target/20260507T231735.301.utd.7ppypa2y1imxmxawpy7ocqrxa-k746klg.1051870)

### jianguoyun

- upload 1.0 GB bytes failed: Transfer failed: Upload failed with status: 413 Payload Too Large

