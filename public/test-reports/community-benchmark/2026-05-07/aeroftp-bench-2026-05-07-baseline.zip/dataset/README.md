# AeroFTP Community Benchmark v3.7.3 — dataset 2026-05-07

> **Sweep date**: 2026-05-07 / 2026-05-08 (overnight tail)
> **CLI version**: aeroftp 3.7.3 (release binary build 2026-05-07 18:44, includes the
> 5 benchmark fixes locally committed as `253f2cc2` + `8e0f0b8f` after the v3.7.3 tag)
> **Issue tracker**: [axpdev-lab/aeroftp#177](https://github.com/axpdev-lab/aeroftp/issues/177)
> **Schema version**: 1 (see `docs/dev/roadmap/APPENDIX-BENCHMARK/01_JSON-Schema-v1.md`)

This bundle is the **deliverable** of the first community benchmark round.
All `reports/*.json` are sanitization-passed: no email, no IP, no path
prefix, no token, no bucket name. They are ready to attach to issue #177.

## Contents

```
reports/                          27 valid + 5 partial + 3 v3.7.4 verify JSON reports
                                    *_v374-verify.json -> post-fix verification
                                    on Filen, Yandex, Drime
summaries/
  summary-custom1g.csv            sweep status (profile,protocol,status,duration)
  summary-standard.csv            earlier WebDAV+OpenDrive sweep
  summary-verify.csv              fix-verification sweep
  analyze-custom1g.csv            one row per (profile,operation,payload,p50,p95,...)
rankings/
  rankings-custom1g.md            top performers per payload size
profiles-deep.txt                 manifest used for the main custom1g sweep
profiles-recovered.txt            manifest used for the post-fix recovery sweep
profiles-skipped.txt              profiles deliberately excluded with rationale
                                    (kDrive + SeaFile reserved for a sub-path
                                    matrix in a separate round)
```

## Sweep matrix

`benchmark custom --sizes 1M,10M,100M,1G --runs 3 --consent-publish`

5 operations per (size, run): upload, download, list, stat, delete.

## Coverage summary

| Class | Profiles |
|---|---|
| Full matrix (1M+10M+100M+1G all OK) | AWS, Cloudflare R2, Alibaba OSS, S3 Storj, Tencent, S5 FileLu (FileLu, NOT Filen), Mega S3, Google S3, S3Drive, Drime, Internxt, Jotta, Koofr (native), FileLu, My Mega, My Google Drive, My Dropbox, OneDrive, pCloud, Zoho (cap 100M), AzureBlob, My Koofr WebDAV, FeliCloud, OneDrive (verify), aeroftp.app FTPS |
| Partial (cap before 1G) | jianguoyun (CN, 1G fails), WebDav DriveHQ (free quota at 1G), MyBox (250 MB cap), Internxt (10 GB free quota saturated), Filen Dev (chunk-413 bug, in dedicated handoff) |
| Hard-failed | Yandex (Y2 transient, fixed in dedicated handoff), idrive S3 (timeout: needs 3600s cap), InfiniCloud jp (1G stuck at setup), S5 FileLu (path-not-found bug, FileLu provider) |

## Top performers (1 GB payload)

```
upload p50 (Mbps)              download p50 (Mbps)
1. pCloud         281.8        1. Google S3         585.1
2. Jotta          271.2        2. Mega S3           584.9
3. AzureBlob      281.3 (100M) 3. Tencent           569.3
4. My Dropbox     240.5        4. Alibaba OSS       556.5
5. Alibaba OSS    209.3        5. Jotta             471.1
6. aeroftp.app    201.0 (FTPS) 6. FileLu            412.8
7. S3 Storj       188.1        7. My Google Drive   304.5
8. Cloudflare R2  185.0        8. Cloudflare R2     286.6
9. FileLu         183.8        9. Drime (100M)      273.2
10. Tencent       178.0       10. My Mega           229.8
```

## Fixes that were exercised by the sweep

The CLI binary used during this sweep includes 5 local fixes
(committed in `253f2cc2` + `8e0f0b8f`, in queue for the next release
after v3.7.3):

| # | Fix | Verified by |
|---|---|---|
| 1 | `benchmark_sanitize` substitutes PII before assertion | FeliCloud, AzureBlob (reports written instead of rejected) |
| 2 | `SigpipeIgnoreGuard` wraps `cmd_benchmark` | AzureBlob, S3 Backblaze, Yandex (no more rc=141) |
| 3 | OneDrive nested `mkdir` splits relative path on `/` | OneDrive (full matrix in 178s) |
| 4 | Drime `list()` no longer mutates `current_path` | Drime (full matrix in 65s) |
| 5 | HTTP `read_timeout` 300s → 1800s on all 24 providers | My Koofr WebDAV (1G upload in 1010s instead of dying at 5min) |

## Known open bugs (not fixed in this sweep)

| Bug | Provider | Status |
|---|---|---|
| Chunked AES-GCM upload (1 MiB / `index=N`) | Filen native | **CLOSED** in v3.7.4 (`22a4bd8f` + per-chunk retry `d16a63cc`). Verified by `Filen_Dev_v374-verify.json`: 21 runs / 444 MB / 195 s / 0 errors at 1M+10M+100M |
| Y2 retry-with-fresh-upload-target | Yandex Disk | **CLOSED** in queue (`cb1e80b6`, post-v3.7.4 commit). Verified by `Yandex_v374-verify.json`: 7 runs / 4 MB / 36 s / 0 errors at 1 M. 10 M and 100 M still hit the Yandex free-tier server upload cap (~1 Mbps), separate work item: chunked resumable upload with `Content-Range` |
| Drime `list()` mutated `current_path` | Drime | **CLOSED** in v3.7.4 (`253f2cc2`). Verified by `Drime_v374-verify.json`: 21 runs / 444 MB / 87 s / 0 errors at 1M+10M+100M |
| Drime mkdir 422 not mapped to `AlreadyExists` | Drime | **CLOSED** post-v3.7.4 (Drime mkdir now maps `422 Unprocessable Entity` + "Folder with same name already exists" body to `ProviderError::AlreadyExists`). Cosmetic warning eliminated |
| Y3 (emerged after Y2 close) | Yandex Disk | OPEN in dedicated tab |
| Benchmark assumes overwrite-on-PUT | 4shared | OPEN: 403 on rerun, CLI should `delete` between runs for strict providers |
| 1G timeout cap for slow storage | idrive S3, InfiniCloud jp | OPEN: bench should accept `--per-profile-timeout` flag (3600s for cold-storage backends) |
| Sub-path matrix needed | kDrive, SeaFile WebDAV | OPEN: both providers refuse operations on `/`, need a sub-path benchmark variant. Reserved for a separate round |

## Profiles deliberately not in this dataset

See `profiles-skipped.txt`. Includes user-instructed skips (Lumo NAS, Quotaless,
Wasabi), local Filen bridges (now with their own handoff), GitHub repos, FTP
Aruba duplicates, and media services (ImageKit, Uploadcare, Cloudinary, which
need a separate workflow because they are CDN/transformation, not generic file
storage).

## How to reproduce

```bash
# Use the same CLI binary or rebuild from the post-v3.7.3 main branch
CLI=/var/www/html/FTP_CLIENT_GUI/src-tauri/target/release/aeroftp-cli

# Single profile re-run example
"$CLI" --profile "AWS" benchmark custom \
  --sizes 1M,10M,100M,1G --runs 3 \
  --consent-publish --report ./AWS.json

# Full sweep manifest
cd /home/axpdev/aeroftp-bench-reports/2026-05-07
./run-benchmark.sh custom1g profiles-deep.txt
```

## License / attribution

This dataset was produced on a single residential connection, single host,
single timezone (Western Europe, fiber). It is intended as a **reference
sample**, not a population-level benchmark. The published comparison page
must explicitly call out this selection bias and aggregate across community
submissions before drawing protocol-level conclusions.
